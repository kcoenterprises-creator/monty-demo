<?php
/**
 * Site footer.
 *
 * @package monystyles
 */
$mony_tiktok = 'https://www.tiktok.com/@' . mony_opt( 'tiktok_user' );
?>
</main>

<footer>
	<div class="wrap">
		<div class="fgrid">
			<div>
				<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
				<p style="margin:0;max-width:22em">Keratin, nanoplastia, balayage and hair extensions in Luton.</p>
			</div>
			<div>
				<h4>Pages</h4>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'depth'          => 1,
						'fallback_cb'    => 'mony_fallback_menu',
					)
				);
				?>
			</div>
			<div>
				<h4>Find us</h4>
				<ul>
					<li><?php echo esc_html( mony_opt( 'hours_1' ) ); ?></li>
					<?php if ( mony_opt( 'hours_2' ) ) : ?><li><?php echo esc_html( mony_opt( 'hours_2' ) ); ?></li><?php endif; ?>
					<li><?php echo esc_html( mony_opt( 'address' ) ); ?></li>
					<li><?php echo esc_html( mony_opt( 'phone_display' ) ); ?></li>
					<li><a href="<?php echo esc_url( $mony_tiktok ); ?>" target="_blank" rel="noopener">TikTok</a></li>
				</ul>
			</div>
		</div>
		<div class="fbase">&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>, Luton</div>
	</div>
</footer>

<a class="wa" href="<?php echo esc_url( mony_wa_link() ); ?>" target="_blank" rel="noopener">Book on WhatsApp</a>

<?php wp_footer(); ?>
</body>
</html>
