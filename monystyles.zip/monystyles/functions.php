<?php
/**
 * Mony Styles theme functions.
 *
 * @package monystyles
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MONY_VERSION', '1.0.0' );

/* -------------------------------------------------------------------------
 * Defaults for every editable setting (Appearance > Customize > Mony Styles)
 * ---------------------------------------------------------------------- */
function mony_defaults() {
	return array(
		'show_demo_bar'   => true,
		'whatsapp'        => '440000000000',
		'phone_display'   => '07000 000000',
		'address'         => 'Salon address, Luton LU1',
		'hours_1'         => 'Tuesday to Saturday, 9:30am to 7pm',
		'hours_2'         => 'Sunday and Monday by request',
		'tiktok_user'     => 'monystyleluton',
		'map_embed'       => '',
		'hero_image'      => 'https://images.unsplash.com/photo-1542745719-d90adc278e1f?fm=jpg&q=70&w=1800&fit=crop',
		'about_image'     => '',
		'hero_video_1'    => 'https://www.tiktok.com/@monystyleluton/video/7707463276103240962',
		'hero_video_2'    => 'https://www.tiktok.com/@monystyleluton/video/7665138691102412055',
		'hero_video_3'    => 'https://www.tiktok.com/@monystyleluton/video/7699967518047309078',
		'price_keratin'   => 'from £120',
		'price_nano'      => 'from £90',
		'price_balayage'  => 'from £130',
		'price_ext'       => 'from £200',
		'price_cuts'      => 'from £40',
		'price_mens'      => 'from £20',
		'price_blowdry'   => 'from £25',
		'video_keratin'   => 'https://www.tiktok.com/@monystyleluton/video/7705201614126140694',
		'video_nano'      => 'https://www.tiktok.com/@monystyleluton/video/7707463276103240962',
		'video_balayage'  => 'https://www.tiktok.com/@monystyleluton/video/7665138691102412055',
		'video_ext'       => 'https://www.tiktok.com/@monystyleluton/photo/7691784016202157334',
		'video_cuts'      => 'https://www.tiktok.com/@monystyleluton/video/7701141574176017686',
		'result_1'        => 'https://www.tiktok.com/@monystyleluton/video/7699967518047309078',
		'result_2'        => 'https://www.tiktok.com/@monystyleluton/video/7667921666533510403',
		'result_3'        => 'https://www.tiktok.com/@monystyleluton/video/7692205131449847062',
		'review_1_text'   => '',
		'review_1_name'   => '',
		'review_2_text'   => '',
		'review_2_name'   => '',
		'review_3_text'   => '',
		'review_3_name'   => '',
	);
}

/** Get one setting, falling back to its default. */
function mony_opt( $key ) {
	$defaults = mony_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	return get_theme_mod( $key, $default );
}

/* -------------------------------------------------------------------------
 * Theme setup
 * ---------------------------------------------------------------------- */
function mony_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 88, 'width' => 300, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'responsive-embeds' );
	register_nav_menus( array( 'primary' => __( 'Main menu', 'monystyles' ) ) );
}
add_action( 'after_setup_theme', 'mony_setup' );

function mony_assets() {
	wp_enqueue_style( 'mony-fonts', 'https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Heebo:wght@300;400;500&display=swap', array(), null );
	wp_enqueue_style( 'mony-style', get_stylesheet_uri(), array( 'mony-fonts' ), MONY_VERSION );
	wp_enqueue_script( 'mony-site', get_template_directory_uri() . '/assets/site.js', array(), MONY_VERSION, true );
	wp_localize_script(
		'mony-site',
		'MONY',
		array(
			'wa' => preg_replace( '/\D/', '', (string) mony_opt( 'whatsapp' ) ),
		)
	);
	if ( is_page( 'services' ) ) {
		wp_enqueue_script( 'tiktok-embed', 'https://www.tiktok.com/embed.js', array(), null, true );
	}
}
add_action( 'wp_enqueue_scripts', 'mony_assets' );

function mony_preconnect( $urls, $relation ) {
	if ( 'preconnect' === $relation ) {
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'mony_preconnect', 10, 2 );

/* -------------------------------------------------------------------------
 * Helpers
 * ---------------------------------------------------------------------- */

/** Link to one of the theme's pages by its slug. */
function mony_page_url( $slug ) {
	if ( 'home' === $slug ) {
		return home_url( '/' );
	}
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/** WhatsApp link with a message ready to send. */
function mony_wa_link( $text = "Hi Mony, I'd like to book an appointment." ) {
	$num = preg_replace( '/\D/', '', (string) mony_opt( 'whatsapp' ) );
	return 'https://wa.me/' . $num . '?text=' . rawurlencode( $text );
}

/** Pull the numeric post id out of a TikTok link. */
function mony_tiktok_id( $url ) {
	if ( preg_match( '/(\d{15,22})/', (string) $url, $m ) ) {
		return $m[1];
	}
	return '';
}

/**
 * Output a TikTok post. Videos use TikTok's player, photo posts use TikTok's embed code.
 *
 * @param string $url   TikTok link.
 * @param string $title Accessible title.
 * @param string $class Extra class for the iframe.
 */
function mony_tiktok( $url, $title, $class = 'embed lazy' ) {
	$id = mony_tiktok_id( $url );
	if ( ! $id ) {
		return;
	}
	if ( false !== strpos( (string) $url, '/photo/' ) ) {
		$user = mony_opt( 'tiktok_user' );
		$link = 'https://www.tiktok.com/@' . $user . '/photo/' . $id;
		printf(
			'<blockquote class="tiktok-embed embedq" cite="%1$s" data-video-id="%2$s"><section><a target="_blank" rel="noopener" href="%1$s">%3$s</a></section></blockquote>',
			esc_url( $link ),
			esc_attr( $id ),
			esc_html( $title . ' on TikTok' )
		);
		return;
	}
	printf(
		'<iframe class="%1$s" data-id="%2$s" title="%3$s" allow="fullscreen; encrypted-media" allowfullscreen></iframe>',
		esc_attr( $class ),
		esc_attr( $id ),
		esc_attr( $title )
	);
}

/** The five treatments, used on Home and Services. */
function mony_treatments() {
	return array(
		'keratin'     => array(
			'title' => 'Keratin smoothing',
			'short' => 'Frizz-free, shiny hair for 3 to 5 months.',
			'desc'  => 'Cuts frizz and halves your blow-dry time. Hair stays smooth and shiny for 3 to 5 months, and the result fades gently rather than leaving a line.',
			'facts' => array( 'Time' => '2 to 4 hours', 'Lasts' => '3 to 5 months', 'Good for' => 'Frizzy, puffy or hard-to-manage hair' ),
			'price' => 'price_keratin',
			'video' => 'video_keratin',
			'book'  => 'Book keratin smoothing',
		),
		'nanoplastia' => array(
			'title' => 'Nanoplastia and hair botox',
			'short' => 'Gentle smoothing and deep repair for coloured hair.',
			'desc'  => 'Nanoplastia is a formaldehyde-free straightener for a sleek, natural finish. Hair botox is a deep repair treatment that brings back softness and shine without straightening.',
			'facts' => array( 'Time' => '2 to 3 hours', 'Lasts' => '2 to 5 months', 'Good for' => 'Coloured, bleached or damaged hair' ),
			'price' => 'price_nano',
			'video' => 'video_nano',
			'book'  => 'Book nanoplastia or botox',
		),
		'balayage'    => array(
			'title' => 'Balayage and colour',
			'short' => 'Hand-painted colour that grows out softly.',
			'desc'  => 'Hand-painted colour that grows out softly, so you need fewer salon visits. Includes toner and a blow-dry. Full colour and root touch-ups also available.',
			'facts' => array( 'Time' => '3 to 5 hours', 'Refresh' => 'Every 3 to 4 months', 'Good for' => 'Low-maintenance colour, brightening dark hair' ),
			'price' => 'price_balayage',
			'video' => 'video_balayage',
			'book'  => 'Book balayage',
		),
		'extensions'  => array(
			'title' => 'Hair extensions',
			'short' => 'Length and volume, matched to your shade.',
			'desc'  => 'Tape-in and keratin bond extensions in natural hair. Mony matches the shade to your own hair, so the join is invisible.',
			'facts' => array( 'Time' => '2 to 4 hours', 'Upkeep' => 'Move-up every 6 to 8 weeks', 'Good for' => 'Adding length or volume, fine hair' ),
			'price' => 'price_ext',
			'video' => 'video_ext',
			'book'  => 'Book an extensions consultation',
		),
		'cuts'        => array(
			'title' => 'Cuts and styling',
			'short' => "Women's, men's and curly cuts.",
			'desc'  => "Women's, men's and curly cuts, shaped to suit how you actually wear your hair every day. Blow-dries and occasion styling too.",
			'facts' => array( "Women's cut and blow-dry" => 'price_cuts', "Men's cut" => 'price_mens', 'Blow-dry' => 'price_blowdry' ),
			'price' => 'price_cuts',
			'video' => 'video_cuts',
			'book'  => 'Book a cut',
		),
	);
}

/** Link to the contact page with a treatment already chosen in the form. */
function mony_book_url( $key ) {
	return add_query_arg( 'treatment', $key, mony_page_url( 'contact' ) );
}

/** Fallback menu when no menu has been set up yet. */
function mony_fallback_menu() {
	echo '<ul>';
	foreach ( array( 'home' => 'Home', 'services' => 'Services and prices', 'about' => 'About Mony', 'contact' => 'Contact' ) as $slug => $label ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( mony_page_url( $slug ) ), esc_html( $label ) );
	}
	echo '</ul>';
}

/* -------------------------------------------------------------------------
 * Customizer: Appearance > Customize > Mony Styles
 * ---------------------------------------------------------------------- */
function mony_sanitize_checkbox( $v ) {
	return ! empty( $v );
}
function mony_sanitize_digits( $v ) {
	return preg_replace( '/\D/', '', (string) $v );
}
function mony_sanitize_user( $v ) {
	return preg_replace( '/[^A-Za-z0-9._]/', '', ltrim( (string) $v, '@' ) );
}
function mony_sanitize_map( $v ) {
	// Accept either the full Google Maps <iframe> code or just its src link.
	if ( preg_match( '/src="([^"]+)"/', (string) $v, $m ) ) {
		$v = $m[1];
	}
	$v = esc_url_raw( trim( (string) $v ) );
	return ( 0 === strpos( $v, 'https://www.google.com/maps/embed' ) ) ? $v : '';
}

function mony_customize( $wp_customize ) {
	$d = mony_defaults();

	$wp_customize->add_panel( 'mony', array( 'title' => 'Mony Styles', 'priority' => 20 ) );

	$sections = array(
		'mony_details' => 'Salon details',
		'mony_prices'  => 'Prices',
		'mony_media'   => 'Photos and videos',
		'mony_reviews' => 'Client reviews',
	);
	foreach ( $sections as $id => $title ) {
		$wp_customize->add_section( $id, array( 'title' => $title, 'panel' => 'mony' ) );
	}

	$text = function ( $key, $label, $section, $desc = '', $sanitize = 'sanitize_text_field', $type = 'text' ) use ( $wp_customize, $d ) {
		$wp_customize->add_setting( $key, array( 'default' => $d[ $key ], 'sanitize_callback' => $sanitize ) );
		$wp_customize->add_control( $key, array( 'label' => $label, 'section' => $section, 'type' => $type, 'description' => $desc ) );
	};

	// Salon details.
	$wp_customize->add_setting( 'show_demo_bar', array( 'default' => $d['show_demo_bar'], 'sanitize_callback' => 'mony_sanitize_checkbox' ) );
	$wp_customize->add_control( 'show_demo_bar', array( 'label' => 'Show the "demo preview" bar at the top', 'description' => 'Untick this before the site goes live.', 'section' => 'mony_details', 'type' => 'checkbox' ) );
	$text( 'whatsapp', 'WhatsApp number', 'mony_details', 'Country code then number, no + or spaces. Example: 447123456789', 'mony_sanitize_digits' );
	$text( 'phone_display', 'Phone number as shown on the site', 'mony_details' );
	$text( 'address', 'Salon address', 'mony_details' );
	$text( 'hours_1', 'Opening hours, line 1', 'mony_details' );
	$text( 'hours_2', 'Opening hours, line 2', 'mony_details' );
	$text( 'tiktok_user', 'TikTok username', 'mony_details', 'Without the @', 'mony_sanitize_user' );
	$text( 'map_embed', 'Google Maps embed', 'mony_details', 'In Google Maps: Share > Embed a map > Copy HTML, then paste it here.', 'mony_sanitize_map', 'textarea' );

	// Prices.
	$labels = array(
		'price_keratin'  => 'Keratin smoothing',
		'price_nano'     => 'Nanoplastia and hair botox',
		'price_balayage' => 'Balayage and colour',
		'price_ext'      => 'Hair extensions',
		'price_cuts'     => "Women's cut and blow-dry",
		'price_mens'     => "Men's cut",
		'price_blowdry'  => 'Blow-dry',
	);
	foreach ( $labels as $key => $label ) {
		$text( $key, $label, 'mony_prices', '', 'sanitize_text_field' );
	}

	// Photos and videos.
	$wp_customize->add_setting( 'hero_image', array( 'default' => $d['hero_image'], 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hero_image', array( 'label' => 'Homepage background photo', 'description' => 'Shows behind the homepage videos while they load. Use a wide photo, at least 1800px across.', 'section' => 'mony_media' ) ) );
	$wp_customize->add_setting( 'about_image', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'about_image', array( 'label' => 'Photo of Mony', 'description' => 'Upright (portrait) photo works best.', 'section' => 'mony_media' ) ) );
	$videos = array(
		'hero_video_1'   => 'Homepage background video 1',
		'hero_video_2'   => 'Homepage background video 2',
		'hero_video_3'   => 'Homepage background video 3',
		'video_keratin'  => 'Keratin smoothing video',
		'video_nano'     => 'Nanoplastia and botox video',
		'video_balayage' => 'Balayage video',
		'video_ext'      => 'Hair extensions post',
		'video_cuts'     => 'Cuts and styling video',
		'result_1'       => 'Recent result 1',
		'result_2'       => 'Recent result 2',
		'result_3'       => 'Recent result 3',
	);
	foreach ( $videos as $key => $label ) {
		$text( $key, $label, 'mony_media', 'Paste the TikTok link.', 'esc_url_raw', 'url' );
	}

	// Reviews.
	for ( $i = 1; $i <= 3; $i++ ) {
		$text( "review_{$i}_text", "Review {$i}: what the client said", 'mony_reviews', 1 === $i ? 'Copy real reviews from Google. The section stays hidden until at least one review is filled in.' : '', 'sanitize_textarea_field', 'textarea' );
		$text( "review_{$i}_name", "Review {$i}: client name and treatment", 'mony_reviews' );
	}
}
add_action( 'customize_register', 'mony_customize' );

/* -------------------------------------------------------------------------
 * On activation: create the four pages, set the homepage and the menu.
 * Runs only for things that don't exist yet, so it never overwrites edits.
 * ---------------------------------------------------------------------- */
function mony_default_about_text() {
	return "<!-- wp:paragraph -->\n<p>Mony specialises in smoothing treatments, colour and hair extensions. She keeps her skills current with intensive advanced courses, most recently in London.</p>\n<!-- /wp:paragraph -->\n\n"
		. "<!-- wp:paragraph -->\n<p>She runs the salon herself, so you see the same person at every visit. She'll tell you honestly what your hair can take, and what it can't.</p>\n<!-- /wp:paragraph -->\n\n"
		. "<!-- wp:paragraph -->\n<p>Her work is on TikTok every week, from frizzy-to-sleek keratin results to full balayage transformations.</p>\n<!-- /wp:paragraph -->";
}

function mony_activate() {
	$pages = array(
		'home'     => array( 'Home', '' ),
		'services' => array( 'Services and prices', '' ),
		'about'    => array( 'About Mony', mony_default_about_text() ),
		'contact'  => array( 'Contact', '' ),
	);
	$ids   = array();
	foreach ( $pages as $slug => $info ) {
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			$ids[ $slug ] = $existing->ID;
			continue;
		}
		$ids[ $slug ] = wp_insert_post(
			array(
				'post_title'   => $info[0],
				'post_name'    => $slug,
				'post_content' => $info[1],
				'post_status'  => 'publish',
				'post_type'    => 'page',
			)
		);
	}

	if ( ! empty( $ids['home'] ) && 'page' !== get_option( 'show_on_front' ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', (int) $ids['home'] );
	}

	// Pretty links (example.com/services/) are needed for the page templates to look tidy.
	if ( '' === get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
		flush_rewrite_rules();
	}

	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( empty( $locations['primary'] ) ) {
		$menu = wp_get_nav_menu_object( 'Main menu' );
		$menu_id = $menu ? $menu->term_id : wp_create_nav_menu( 'Main menu' );
		if ( ! is_wp_error( $menu_id ) ) {
			if ( ! $menu || ! wp_get_nav_menu_items( $menu_id ) ) {
				$order = 1;
				foreach ( array( 'home', 'services', 'about', 'contact' ) as $slug ) {
					if ( empty( $ids[ $slug ] ) ) {
						continue;
					}
					wp_update_nav_menu_item(
						$menu_id,
						0,
						array(
							'menu-item-object-id' => (int) $ids[ $slug ],
							'menu-item-object'    => 'page',
							'menu-item-type'      => 'post_type',
							'menu-item-status'    => 'publish',
							'menu-item-position'  => $order++,
						)
					);
				}
			}
			$locations['primary'] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}
}
add_action( 'after_switch_theme', 'mony_activate' );

/* Tidy page titles in the browser tab. */
function mony_title_parts( $parts ) {
	if ( is_front_page() ) {
		$parts['title']   = get_bloginfo( 'name' );
		$parts['tagline'] = 'Keratin, Balayage & Hair Extensions in Luton';
	}
	return $parts;
}
add_filter( 'document_title_parts', 'mony_title_parts' );

/* Basic search description for Google if no SEO plugin is installed. */
function mony_meta_description() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) ) {
		return;
	}
	$desc = 'Mony Styles is a hair salon in Luton for keratin smoothing, nanoplastia, hair botox, balayage and hair extensions. Book on WhatsApp.';
	echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
}
add_action( 'wp_head', 'mony_meta_description', 1 );
