<?php
/**
 * Fallback template for posts and archives.
 *
 * @package monystyles
 */
get_header();
?>
<div class="wrap pagehead"><h1><?php echo is_home() ? esc_html__( 'News', 'monystyles' ) : wp_kses_post( get_the_archive_title() ); ?></h1></div>
<section style="padding-top:0">
	<div class="wrap entry">
		<?php if ( have_posts() ) : ?>
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article style="margin-bottom:48px">
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<?php is_singular() ? the_content() : the_excerpt(); ?>
				</article>
			<?php endwhile; ?>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<p>Nothing here yet.</p>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
