<?php
/**
 * Any other page (for example a privacy policy).
 *
 * @package monystyles
 */
get_header();
while ( have_posts() ) :
	the_post();
	?>
	<div class="wrap pagehead"><h1><?php the_title(); ?></h1></div>
	<section style="padding-top:0"><div class="wrap entry"><?php the_content(); ?></div></section>
	<?php
endwhile;
get_footer();
