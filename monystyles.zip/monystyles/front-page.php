<?php
/**
 * Homepage.
 *
 * @package monystyles
 */
get_header();

$mony_hero_img = mony_opt( 'hero_image' );
$mony_about    = mony_opt( 'about_image' );
$mony_reviews  = array();
for ( $i = 1; $i <= 3; $i++ ) {
	$t = trim( (string) mony_opt( "review_{$i}_text" ) );
	if ( $t ) {
		$mony_reviews[] = array( $t, mony_opt( "review_{$i}_name" ) );
	}
}
$mony_cards = array_intersect_key( mony_treatments(), array_flip( array( 'keratin', 'nanoplastia', 'balayage', 'cuts' ) ) );
?>
<div class="hero-wrap">
	<div class="hero2">
		<div class="hero-bg<?php echo $mony_hero_img ? ' has-photo' : ''; ?>" aria-hidden="true"<?php if ( $mony_hero_img ) : ?> style="--hero-photo:url('<?php echo esc_url( $mony_hero_img ); ?>')"<?php endif; ?>>
			<?php
			for ( $i = 1; $i <= 3; $i++ ) {
				$vid = mony_tiktok_id( mony_opt( "hero_video_{$i}" ) );
				if ( $vid ) {
					printf( '<iframe class="bgvid" data-id="%s" title="" tabindex="-1" allow="autoplay; encrypted-media"></iframe>', esc_attr( $vid ) );
				}
			}
			?>
		</div>
		<div class="hero-shade" aria-hidden="true"></div>
		<div class="hero-copy">
			<h1>The art of smooth, healthy hair</h1>
			<p>Keratin, nanoplastia, balayage and hair extensions in Luton, all done by Mony herself.</p>
			<div class="ctas">
				<a class="btn peach" href="<?php echo esc_url( mony_page_url( 'contact' ) ); ?>">Book your appointment</a>
				<a class="btn ghostlight" href="<?php echo esc_url( mony_page_url( 'services' ) ); ?>">See treatments</a>
			</div>
		</div>
	</div>
</div>

<section>
	<div class="wrap">
		<div class="sechead">
			<div>
				<h2>Signature treatments</h2>
				<p class="lead">Treatments for hair that looks good every day, not just on the day you leave the salon.</p>
			</div>
			<a class="btn" href="<?php echo esc_url( mony_page_url( 'services' ) ); ?>">See all prices</a>
		</div>
		<div class="scards">
			<?php foreach ( $mony_cards as $key => $t ) : ?>
			<article class="scard">
				<div class="scard-media"><?php mony_tiktok( mony_opt( $t['video'] ), $t['title'] . ' by Mony Styles', 'lazy' ); ?></div>
				<div class="scard-body">
					<h3><?php echo esc_html( $t['title'] ); ?></h3>
					<p><?php echo esc_html( $t['short'] ); ?></p>
					<div class="scard-foot"><span><?php echo esc_html( mony_opt( $t['price'] ) ); ?></span><a class="btn small" href="<?php echo esc_url( mony_book_url( $key ) ); ?>">Book now</a></div>
				</div>
			</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="meet">
	<div class="wrap meet-grid">
		<div class="portrait">
			<?php if ( $mony_about ) : ?>
				<img src="<?php echo esc_url( $mony_about ); ?>" alt="Mony in her salon" loading="lazy">
			<?php else : ?>
				<span>Photo of Mony in the salon</span>
			<?php endif; ?>
		</div>
		<div>
			<h2>Meet Mony</h2>
			<p>Mony does every treatment herself, from the consultation to the final blow-dry. She keeps her skills current with advanced courses, most recently in London.</p>
			<p>One stylist means she knows your hair and what it has been through. She'll tell you honestly what it can take.</p>
			<a class="btn" href="<?php echo esc_url( mony_page_url( 'about' ) ); ?>">Read her story</a>
		</div>
	</div>
</section>

<?php if ( $mony_reviews ) : ?>
<section>
	<div class="wrap">
		<h2>Words from clients</h2>
		<p class="lead">What clients say on Google.</p>
		<div class="reviews">
			<?php foreach ( $mony_reviews as $r ) : ?>
			<figure class="review" style="margin:0">
				<blockquote style="margin:0"><p><?php echo esc_html( $r[0] ); ?></p></blockquote>
				<?php if ( $r[1] ) : ?><figcaption><span><?php echo esc_html( $r[1] ); ?></span></figcaption><?php endif; ?>
			</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<section style="background:#fff;border-top:1px solid var(--line)">
	<div class="wrap">
		<h2>Recent results</h2>
		<p class="lead">Straight from the salon's TikTok. Press play to watch the full transformation.</p>
		<div class="results-grid">
			<?php
			for ( $i = 1; $i <= 3; $i++ ) {
				mony_tiktok( mony_opt( "result_{$i}" ), 'Client result by Mony Styles' );
			}
			?>
		</div>
		<div class="follow">
			<a class="btn ghost" href="<?php echo esc_url( 'https://www.tiktok.com/@' . mony_opt( 'tiktok_user' ) ); ?>" target="_blank" rel="noopener">Follow @<?php echo esc_html( mony_opt( 'tiktok_user' ) ); ?></a>
			<span>New results every week.</span>
		</div>
	</div>
</section>

<section class="cta-big">
	<div class="wrap">
		<h2>Ready for a change?</h2>
		<p>Send a photo of your hair and Mony will reply with a price and her next free slots.</p>
		<a class="btn peach" href="<?php echo esc_url( mony_page_url( 'contact' ) ); ?>">Book your appointment</a>
	</div>
</section>
<?php
get_footer();
