<?php
/**
 * Page not found.
 *
 * @package monystyles
 */
get_header();
?>
<div class="wrap pagehead">
	<h1>Page not found</h1>
	<p>This page doesn't exist. Try the homepage or book an appointment.</p>
	<div class="ctas" style="margin-top:30px">
		<a class="btn" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go to homepage</a>
		<a class="btn ghost" href="<?php echo esc_url( mony_page_url( 'contact' ) ); ?>">Book an appointment</a>
	</div>
</div>
<section></section>
<?php
get_footer();
