<?php
/**
 * Site header.
 *
 * @package monystyles
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#main">Skip to content</a>

<?php if ( mony_opt( 'show_demo_bar' ) ) : ?>
<div class="demo">Demo preview made for Mony Styles. Prices, address and phone are samples until confirmed.</div>
<?php endif; ?>

<header id="hdr">
	<nav aria-label="Main">
		<?php if ( has_custom_logo() ) : ?>
			<?php the_custom_logo(); ?>
		<?php else : ?>
			<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?> <small>Luton</small></a>
		<?php endif; ?>
		<button class="menu-btn" type="button" aria-expanded="false" aria-controls="navlinks">Menu</button>
		<div class="navlinks" id="navlinks">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'depth'          => 1,
					'fallback_cb'    => 'mony_fallback_menu',
				)
			);
			?>
			<a class="btn" href="<?php echo esc_url( mony_page_url( 'contact' ) ); ?>">Book now</a>
		</div>
	</nav>
</header>

<main id="main">
