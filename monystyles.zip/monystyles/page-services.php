<?php
/**
 * Services and prices page (used automatically for the page with the slug "services").
 *
 * @package monystyles
 */
get_header();
$mony_t = mony_treatments();
?>
<div class="wrap pagehead">
	<h1><?php the_title(); ?></h1>
	<p>Each treatment shows a real result from the salon. Prices depend on your hair length and thickness. Mony confirms the final price at your consultation, before any work starts.</p>
	<nav class="jump" aria-label="Treatments">
		<?php foreach ( $mony_t as $key => $t ) : ?>
			<a href="#t-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $t['title'] ); ?></a>
		<?php endforeach; ?>
		<a href="#t-faq">Questions</a>
	</nav>
</div>

<div class="wrap">
	<?php foreach ( $mony_t as $key => $t ) : ?>
	<article class="treat" id="t-<?php echo esc_attr( $key ); ?>">
		<div class="media"><?php mony_tiktok( mony_opt( $t['video'] ), $t['title'] . ' by Mony Styles' ); ?></div>
		<div class="tinfo">
			<h2 style="font-size:clamp(30px,3.4vw,42px);margin:0 0 6px"><?php echo esc_html( $t['title'] ); ?></h2>
			<p class="price"><?php echo esc_html( mony_opt( $t['price'] ) ); ?></p>
			<p><?php echo esc_html( $t['desc'] ); ?></p>
			<dl class="facts">
				<?php foreach ( $t['facts'] as $label => $value ) : ?>
					<dt><?php echo esc_html( $label ); ?></dt>
					<dd><?php echo esc_html( 0 === strpos( $value, 'price_' ) ? mony_opt( $value ) : $value ); ?></dd>
				<?php endforeach; ?>
			</dl>
			<a class="btn ghost" href="<?php echo esc_url( mony_book_url( $key ) ); ?>"><?php echo esc_html( $t['book'] ); ?></a>
		</div>
	</article>
	<?php endforeach; ?>
</div>

<?php
while ( have_posts() ) :
	the_post();
	if ( trim( get_the_content() ) ) :
		?>
<section style="padding-bottom:0"><div class="wrap entry"><?php the_content(); ?></div></section>
		<?php
	endif;
endwhile;
?>

<section id="t-faq" style="scroll-margin-top:110px">
	<div class="wrap faq">
		<h2>Questions clients ask</h2>
		<details><summary>Do I need a consultation first?</summary><p>For keratin, nanoplastia, colour and extensions, yes. It's free and takes about 15 minutes. Mony checks your hair, does a strand test and gives you a final price.</p></details>
		<details><summary>Can I wash my hair after keratin?</summary><p>Mony will tell you exactly when, as it depends on the product used. You'll also get aftercare tips and advice on the right sulphate-free shampoo to keep the result longer.</p></details>
		<details><summary>Is nanoplastia safe for coloured hair?</summary><p>It's usually a good choice for coloured hair because it is formaldehyde-free. The strand test confirms it before any work starts.</p></details>
		<details><summary>Do you offer discounts?</summary><p>Yes. Mony posts offers on TikTok, so follow @<?php echo esc_html( mony_opt( 'tiktok_user' ) ); ?> to catch them.</p></details>
	</div>
</section>

<section class="band">
	<div class="wrap">
		<h2>Not sure which treatment?</h2>
		<p>Send a photo of your hair. Mony will suggest the right one and tell you the price.</p>
		<a class="btn" href="<?php echo esc_url( mony_page_url( 'contact' ) ); ?>">Ask Mony</a>
	</div>
</section>
<?php
get_footer();
