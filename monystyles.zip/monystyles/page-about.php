<?php
/**
 * About page (slug "about"). The text comes from the page editor, so it can be changed in WordPress.
 *
 * @package monystyles
 */
get_header();
$mony_about = mony_opt( 'about_image' );
?>
<div class="wrap pagehead">
	<h1><?php the_title(); ?></h1>
	<p>The stylist behind every treatment at <?php bloginfo( 'name' ); ?>.</p>
</div>
<section style="padding-top:20px">
	<div class="wrap about-grid">
		<div class="portrait">
			<?php if ( $mony_about ) : ?>
				<img src="<?php echo esc_url( $mony_about ); ?>" alt="Mony in her salon">
			<?php else : ?>
				<span>Photo of Mony in the salon</span>
			<?php endif; ?>
		</div>
		<div class="about-text">
			<?php
			while ( have_posts() ) :
				the_post();
				the_content();
			endwhile;
			?>
			<ul class="creds">
				<li>Certified in hair extensions</li>
				<li>Advanced keratin training</li>
				<li>Formaldehyde-free options</li>
			</ul>
			<div class="ctas" style="margin-top:32px">
				<a class="btn" href="<?php echo esc_url( mony_page_url( 'contact' ) ); ?>">Book with Mony</a>
				<a class="btn ghost" href="<?php echo esc_url( 'https://www.tiktok.com/@' . mony_opt( 'tiktok_user' ) ); ?>" target="_blank" rel="noopener">Watch her work</a>
			</div>
		</div>
	</div>
</section>
<section class="values">
	<div class="wrap">
		<h2>What to expect at your visit</h2>
		<p class="lead">Your first visit follows the same simple steps.</p>
		<ol class="steps">
			<li><h3>Consultation</h3><p>Mony looks at your hair, asks what you want and does a strand test if needed.</p></li>
			<li><h3>Your treatment</h3><p>Done by Mony from start to finish, with no rushing between clients.</p></li>
			<li><h3>Aftercare</h3><p>You leave with clear tips to keep your result looking good for longer.</p></li>
		</ol>
	</div>
</section>
<?php
get_footer();
