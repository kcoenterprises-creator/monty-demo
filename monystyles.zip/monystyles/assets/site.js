(function () {
  var PLAYER = "https://www.tiktok.com/player/v1/";
  var Q = "?rel=0&music_info=0&description=0&controls=1";
  var QB = "?autoplay=1&loop=1&controls=0&progress_bar=0&play_button=0&volume_control=0&fullscreen_button=0&timestamp=0&music_info=0&description=0&rel=0&native_context_menu=0&closed_caption=0";

  // Background videos: only load the ones that are visible (one on phones, three on desktop).
  document.querySelectorAll("iframe.bgvid[data-id]").forEach(function (f) {
    if (f.offsetParent !== null) { f.src = PLAYER + f.dataset.id + QB; }
  });

  // Other TikTok videos load when they scroll near the screen.
  var lazy = document.querySelectorAll("iframe.lazy[data-id]");
  function load(f) { if (!f.src) { f.src = PLAYER + f.dataset.id + Q; } }
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { load(e.target); io.unobserve(e.target); } });
    }, { rootMargin: "400px 0px" });
    lazy.forEach(function (f) { io.observe(f); });
  } else {
    lazy.forEach(load);
  }

  // Mobile menu.
  var mb = document.querySelector(".menu-btn");
  var nl = document.getElementById("navlinks");
  if (mb && nl) {
    mb.addEventListener("click", function () {
      var open = nl.classList.toggle("open");
      mb.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  // Booking form: opens WhatsApp with the message written out.
  var form = document.getElementById("bookform");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var nameEl = document.getElementById("f-name");
      var err = document.getElementById("f-err");
      var name = nameEl.value.trim();
      if (!name) { err.textContent = "Add your name so Mony knows who's messaging."; nameEl.focus(); return; }
      err.textContent = "";
      var msg = "Hi Mony, I'm " + name + ". I'd like to book: " + document.getElementById("f-treat").value +
        ". Preferred day: " + document.getElementById("f-day").value + ".";
      var hair = document.getElementById("f-hair").value.trim();
      if (hair) { msg += " About my hair: " + hair; }
      var num = (window.MONY && window.MONY.wa) ? window.MONY.wa : "";
      window.open("https://wa.me/" + num + "?text=" + encodeURIComponent(msg), "_blank", "noopener");
    });
  }
})();
