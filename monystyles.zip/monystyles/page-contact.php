<?php
/**
 * Contact page (slug "contact"). The form opens WhatsApp with the message ready, so no email setup is needed.
 *
 * @package monystyles
 */
get_header();
$mony_map  = mony_opt( 'map_embed' );
$mony_pick = isset( $_GET['treatment'] ) ? sanitize_key( wp_unslash( $_GET['treatment'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$mony_opts = mony_treatments();
?>
<div class="wrap pagehead">
	<h1>Book or ask a question</h1>
	<p>Fill in the form and it opens WhatsApp with your message ready to send. Mony usually replies the same day.</p>
</div>
<section style="padding-top:10px">
	<div class="wrap contact-grid">
		<form id="bookform" novalidate>
			<h2>Request an appointment</h2>
			<label for="f-name">Your name</label>
			<input id="f-name" name="name" autocomplete="name" required>
			<div class="row2">
				<div>
					<label for="f-treat">Treatment</label>
					<select id="f-treat" name="treatment">
						<?php foreach ( $mony_opts as $key => $t ) : ?>
							<option value="<?php echo esc_attr( $t['title'] ); ?>" <?php selected( $mony_pick, $key ); ?>><?php echo esc_html( $t['title'] ); ?></option>
						<?php endforeach; ?>
						<option value="Not sure yet">Not sure yet</option>
					</select>
				</div>
				<div>
					<label for="f-day">Preferred day</label>
					<select id="f-day" name="day">
						<option>Any day</option><option>Tuesday</option><option>Wednesday</option><option>Thursday</option><option>Friday</option><option>Saturday</option>
					</select>
				</div>
			</div>
			<label for="f-hair">Tell Mony about your hair</label>
			<textarea id="f-hair" name="hair" placeholder="For example: shoulder length, coloured last year, very frizzy"></textarea>
			<p class="err" id="f-err" role="alert"></p>
			<button class="btn" type="submit">Send on WhatsApp</button>
			<p class="formnote">Tip: add a photo of your hair in WhatsApp for a more accurate price.</p>
		</form>

		<div class="info">
			<h2>Visit the salon</h2>
			<p class="lead" style="margin-bottom:30px">Appointments only, so you never wait.</p>
			<dl>
				<dt>Address</dt><dd><?php echo esc_html( mony_opt( 'address' ) ); ?></dd>
				<dt>WhatsApp</dt><dd><a href="<?php echo esc_url( mony_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( mony_opt( 'phone_display' ) ); ?></a></dd>
				<dt>Hours</dt><dd><?php echo esc_html( mony_opt( 'hours_1' ) ); ?><?php if ( mony_opt( 'hours_2' ) ) : ?><br><?php echo esc_html( mony_opt( 'hours_2' ) ); ?><?php endif; ?></dd>
				<dt>TikTok</dt><dd><a href="<?php echo esc_url( 'https://www.tiktok.com/@' . mony_opt( 'tiktok_user' ) ); ?>" target="_blank" rel="noopener">@<?php echo esc_html( mony_opt( 'tiktok_user' ) ); ?></a></dd>
			</dl>
			<?php if ( $mony_map ) : ?>
				<div class="map has-embed"><iframe src="<?php echo esc_url( $mony_map ); ?>" title="Map to <?php bloginfo( 'name' ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
			<?php else : ?>
				<div class="map"><div><span class="pin"></span><a href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( mony_opt( 'address' ) ) ); ?>" target="_blank" rel="noopener">Open in Google Maps</a></div></div>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php
get_footer();
